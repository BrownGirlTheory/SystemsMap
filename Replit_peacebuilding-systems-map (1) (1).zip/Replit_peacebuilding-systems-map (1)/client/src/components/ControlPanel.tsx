import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { networkData } from '@/lib/systemsMapData';

interface ControlPanelProps {
  onRunLayout: () => void;
  onFitToScreen: () => void;
}

export default function ControlPanel({ onRunLayout, onFitToScreen }: ControlPanelProps) {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [filters, setFilters] = useState<Record<string, boolean>>({});
  
  // Get all unique groups from the data
  const { data: groups } = useQuery({
    queryKey: ['/api/groups'],
    queryFn: async () => {
      // Extract unique groups from network data
      const uniqueGroups = Array.from(
        new Set(networkData.nodes.map(n => n.data.group).filter(Boolean))
      ).sort();
      
      // Initialize all filters to true
      const initialFilters: Record<string, boolean> = {};
      uniqueGroups.forEach(group => {
        initialFilters[group] = true;
      });
      
      setFilters(initialFilters);
      return uniqueGroups;
    }
  });
  
  const toggleCollapse = () => {
    setIsCollapsed(!isCollapsed);
  };
  
  const handleFilterChange = (group: string, checked: boolean) => {
    // Update the filter state
    setFilters(prev => ({
      ...prev,
      [group]: checked
    }));
    
    // Apply filter to cytoscape instance
    const event = new CustomEvent('filter-change', {
      detail: { group, checked }
    });
    document.dispatchEvent(event);
  };

  return (
    <div className={`fixed top-4 left-4 z-10 bg-white/95 border border-gray-300 p-4 rounded-lg shadow-md max-w-xs overflow-auto ${isCollapsed ? 'h-10 overflow-hidden' : 'max-h-[calc(100vh-120px)]'}`}>
      {!isCollapsed && (
        <>
          <div className="mb-4">
            <h2 className="font-semibold text-gray-800 mb-2">Peacebuilding Systems Map</h2>
            <p className="text-sm text-gray-600">Visualizing relationships between different sectors and systems in peacebuilding</p>
          </div>
          
          <div className="border-t border-gray-200 pt-3 pb-2">
            <h3 className="font-medium text-gray-700 mb-2">Filter by Subsystem</h3>
            <div id="filters" className="space-y-1.5">
              {groups?.map(group => (
                <div key={group} className="flex items-center">
                  <input
                    type="checkbox"
                    id={group}
                    checked={filters[group] || false}
                    onChange={(e) => handleFilterChange(group, e.target.checked)}
                    className="mr-2 h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <label htmlFor={group} className="text-sm text-gray-700">
                    {group}
                  </label>
                </div>
              ))}
            </div>
          </div>
          
          <div className="border-t border-gray-200 pt-3 mt-3">
            <h3 className="font-medium text-gray-700 mb-2">Layout Options</h3>
            <div className="space-y-2">
              <Button 
                onClick={onRunLayout} 
                className="w-full text-sm bg-blue-600 hover:bg-blue-700 text-white"
              >
                Re-run Layout
              </Button>
              <Button 
                onClick={onFitToScreen} 
                className="w-full text-sm bg-gray-200 hover:bg-gray-300 text-gray-800"
                variant="outline"
              >
                Fit to Screen
              </Button>
            </div>
          </div>
        </>
      )}
      
      <div className="md:hidden mt-3 pb-1 text-center">
        <button 
          onClick={toggleCollapse}
          className="text-xs text-blue-600"
        >
          {isCollapsed ? 'Expand Panel' : 'Collapse Panel'}
        </button>
      </div>
    </div>
  );
}
