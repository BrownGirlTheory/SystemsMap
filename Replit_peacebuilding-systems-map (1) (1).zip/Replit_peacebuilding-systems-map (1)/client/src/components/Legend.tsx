import { useState } from 'react';

export default function Legend() {
  const [isCollapsed, setIsCollapsed] = useState(false);
  
  const toggleCollapse = () => {
    setIsCollapsed(!isCollapsed);
  };

  return (
    <div className={`fixed top-4 right-4 z-10 bg-white/90 backdrop-blur-sm border border-gray-200 p-4 rounded-lg shadow-md max-w-xs overflow-auto ${isCollapsed ? 'h-10 overflow-hidden' : 'max-h-[calc(100vh-120px)]'}`}>
      <h3 className="font-medium text-gray-800 mb-3">Systems Legend</h3>
      
      {!isCollapsed && (
        <>
          <div className="space-y-2 mb-4">
            <div className="flex items-center">
              <div className="w-5 h-5 bg-[#7EA172] rounded-sm shadow-sm mr-2.5"></div>
              <span className="text-sm text-gray-700">Individual</span>
            </div>
            <div className="flex items-center">
              <div className="w-5 h-5 bg-[#A0DAA9] rounded-sm shadow-sm mr-2.5"></div>
              <span className="text-sm text-gray-700">Social</span>
            </div>
            <div className="flex items-center">
              <div className="w-5 h-5 bg-[#E5A4A4] rounded-sm shadow-sm mr-2.5"></div>
              <span className="text-sm text-gray-700">Conflict</span>
            </div>
            <div className="flex items-center">
              <div className="w-5 h-5 bg-[#9BCCB4] rounded-sm shadow-sm mr-2.5"></div>
              <span className="text-sm text-gray-700">Peace</span>
            </div>
            <div className="flex items-center">
              <div className="w-5 h-5 bg-[#D4B483] rounded-sm shadow-sm mr-2.5"></div>
              <span className="text-sm text-gray-700">Governance</span>
            </div>
            <div className="flex items-center">
              <div className="w-5 h-5 bg-[#8B8982] rounded-sm shadow-sm mr-2.5"></div>
              <span className="text-sm text-gray-700">Geopolitics</span>
            </div>
            <div className="flex items-center mt-2">
              <div className="w-5 h-5 border-2 border-[#D4AF37] bg-white rounded-sm shadow-sm mr-2.5"></div>
              <span className="text-sm text-gray-700">Feedback Loop</span>
            </div>
          </div>

          <div className="border-t border-gray-200 pt-3">
            <h4 className="font-medium text-gray-800 mb-2 text-sm">Relationship Types</h4>
            <div className="space-y-2 mb-3">
              <div className="flex items-center">
                <div className="w-8 h-1 bg-[#5D8C5A] mr-2.5 rounded-full flex items-center">
                  <div className="w-0 h-0 border-t-3 border-l-3 border-b-3 border-r-3 border-t-transparent border-l-transparent border-b-transparent border-r-[#5D8C5A] ml-auto"></div>
                </div>
                <span className="text-sm text-gray-700">Strengthens</span>
              </div>
              <div className="flex items-center">
                <div className="w-8 h-1 bg-[#C27D7D] mr-2.5 rounded-full flex items-center">
                  <div className="w-0 h-0 border-t-3 border-l-3 border-b-3 border-r-3 border-t-transparent border-l-transparent border-b-transparent border-r-[#C27D7D] ml-auto"></div>
                </div>
                <span className="text-sm text-gray-700">Weakens</span>
              </div>
              <div className="flex items-center">
                <div className="w-8 h-1 bg-[#A9A9A9] mr-2.5 rounded-full flex items-center">
                  <div className="w-0 h-0 border-t-3 border-l-3 border-b-3 border-r-3 border-t-transparent border-l-transparent border-b-transparent border-r-[#A9A9A9] ml-auto"></div>
                </div>
                <span className="text-sm text-gray-700">Stabilizes</span>
              </div>
            </div>
          </div>
        </>
      )}
      
      <div className="md:hidden mt-3 pb-1 text-center">
        <button 
          onClick={toggleCollapse}
          className="text-xs text-green-700 hover:text-green-800 transition-colors"
        >
          {isCollapsed ? 'Show Legend' : 'Hide Legend'}
        </button>
      </div>
    </div>
  );
}
