import { Button } from '@/components/ui/button';

interface MobilePanelToggleProps {
  isVisible: boolean;
  onToggle: () => void;
}

export default function MobilePanelToggle({ isVisible, onToggle }: MobilePanelToggleProps) {
  return (
    <div className="fixed bottom-4 right-4 z-20 md:hidden">
      <Button
        onClick={onToggle}
        className="bg-blue-600 text-white p-3 rounded-full shadow-lg"
        size="icon"
        aria-label={isVisible ? "Hide panels" : "Show panels"}
      >
        <svg 
          xmlns="http://www.w3.org/2000/svg" 
          className="h-6 w-6" 
          fill="none" 
          viewBox="0 0 24 24" 
          stroke="currentColor"
        >
          <path 
            strokeLinecap="round" 
            strokeLinejoin="round" 
            strokeWidth="2" 
            d="M4 6h16M4 12h16m-7 6h7" 
          />
        </svg>
      </Button>
    </div>
  );
}
