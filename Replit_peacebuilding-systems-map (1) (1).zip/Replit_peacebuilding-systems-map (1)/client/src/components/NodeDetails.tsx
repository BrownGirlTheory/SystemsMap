import { Button } from '@/components/ui/button';
import { X } from 'lucide-react';
import { ActiveNode } from '@/lib/systemsMapData';

interface NodeDetailsProps {
  node: ActiveNode;
  onClose: () => void;
}

export default function NodeDetails({ node, onClose }: NodeDetailsProps) {
  // Get the appropriate color for the node group
  const getGroupColor = (group: string) => {
    switch (group) {
      case 'Individual': return 'bg-[#7EA172]';
      case 'Social': return 'bg-[#A0DAA9]';
      case 'Conflict': return 'bg-[#E5A4A4]';
      case 'Peace': return 'bg-[#9BCCB4]';
      case 'Governance': return 'bg-[#D4B483]';
      case 'Geopolitics': return 'bg-[#8B8982]';
      default: return 'bg-gray-200';
    }
  };

  const getBorderColor = (group: string) => {
    switch (group) {
      case 'Individual': return 'border-[#7EA172]';
      case 'Social': return 'border-[#A0DAA9]';
      case 'Conflict': return 'border-[#E5A4A4]';
      case 'Peace': return 'border-[#9BCCB4]';
      case 'Governance': return 'border-[#D4B483]';
      case 'Geopolitics': return 'border-[#8B8982]';
      default: return 'border-gray-200';
    }
  };

  // Helper function to render a connection list with plus/minus indicators
  const renderConnectionList = (
    title: string, 
    items: string[], 
    polarityIndicator: JSX.Element, 
    bgColor: string
  ) => {
    if (!items || items.length === 0) return null;
    
    return (
      <li className="mb-3">
        <div className="flex items-center mb-1.5">
          <div className={`h-5 w-5 ${bgColor} rounded-full mr-1.5 flex items-center justify-center text-white font-bold text-sm`}>
            {polarityIndicator}
          </div>
          <span className="font-medium text-gray-700 text-sm">{title}:</span>
        </div>
        <ul className="list-none ml-3 space-y-0.5">
          {items.map((item, index) => (
            <li key={index} className="flex items-center text-sm text-gray-600">
              <span className="w-3 h-3 mr-1 inline-block"></span>
              {item}
            </li>
          ))}
        </ul>
      </li>
    );
  };

  const groupColorClass = getGroupColor(node.group);
  const borderColorClass = getBorderColor(node.group);

  return (
    <div id="nodeDetails" className={`fixed bottom-20 left-1/2 transform -translate-x-1/2 z-10 bg-white/90 backdrop-blur-sm border ${borderColorClass} p-5 rounded-lg shadow-md max-w-md w-full`}>
      <div className="flex justify-between items-start mb-2">
        <div className="flex items-center">
          <div className={`w-4 h-4 ${groupColorClass} rounded-sm mr-2.5 shadow-sm`}></div>
          <h3 id="nodeTitle" className="font-semibold text-gray-800">{node.label}</h3>
        </div>
        <Button 
          onClick={onClose}
          variant="ghost" 
          className="h-8 w-8 p-0 text-gray-400 hover:text-gray-600"
        >
          <X className="h-5 w-5" />
        </Button>
      </div>
      
      <div id="nodeGroup" className="text-sm font-medium text-gray-600 mb-2">
        {node.group} Subsystem
      </div>
      
      <div id="nodeConnections" className="mt-4">
        <h4 className="font-medium text-gray-800 mb-3 border-b pb-1">System Influences</h4>
        <ul className="space-y-2 mt-3">
          {renderConnectionList(
            'Strengthens', 
            node.connections.strengthens, 
            <span>+</span>, 
            'bg-green-600'
          )}
          {renderConnectionList(
            'Weakens', 
            node.connections.weakens, 
            <span>−</span>, 
            'bg-red-600'
          )}
          {renderConnectionList(
            'Stabilizes', 
            node.connections.stabilizes, 
            <span>○</span>, 
            'bg-gray-500'
          )}
        </ul>
        
        {(node.connections.strengthenedBy.length > 0 || node.connections.weakenedBy.length > 0 || node.connections.stabilizedBy.length > 0) && (
          <h4 className="font-medium text-gray-800 mb-3 mt-5 border-b pb-1">Influenced By</h4>
        )}
        
        <ul className="space-y-2 mt-3">
          {renderConnectionList(
            'Strengthened by', 
            node.connections.strengthenedBy, 
            <span>+</span>, 
            'bg-green-600'
          )}
          {renderConnectionList(
            'Weakened by', 
            node.connections.weakenedBy, 
            <span>−</span>, 
            'bg-red-600'
          )}
          {renderConnectionList(
            'Stabilized by', 
            node.connections.stabilizedBy, 
            <span>○</span>, 
            'bg-gray-500'
          )}
        </ul>
      </div>
      
      {/* Relationship Key */}
      <div className="mt-5 pt-3 border-t border-gray-200">
        <div className="flex items-center justify-center space-x-4 text-xs text-gray-600">
          <div className="flex items-center">
            <div className="h-4 w-4 bg-green-600 rounded-full flex items-center justify-center text-white font-bold text-xs mr-1">+</div>
            <span>Strengthens</span>
          </div>
          <div className="flex items-center">
            <div className="h-4 w-4 bg-red-600 rounded-full flex items-center justify-center text-white font-bold text-xs mr-1">−</div>
            <span>Weakens</span>
          </div>
          <div className="flex items-center">
            <div className="h-4 w-4 bg-gray-500 rounded-full flex items-center justify-center text-white font-bold text-xs mr-1">○</div>
            <span>Stabilizes</span>
          </div>
        </div>
      </div>
    </div>
  );
}
