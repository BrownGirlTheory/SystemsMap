import { NodeData } from '@/lib/systemsMapData';
import React, { useEffect, useRef, useState } from 'react';

interface SystemsMapProps {
  setCy: (cy: any) => void;
  onNodeClick: (node: any) => void;
}

// Get color based on group
const getGroupColor = (group: string) => {
  switch (group) {
    case 'Individual': return '#7EA172';
    case 'Social': return '#A0DAA9';
    case 'Conflict': return '#E5A4A4';
    case 'Peace': return '#9BCCB4';
    case 'Governance': return '#D4B483';
    case 'Geopolitics': return '#8B8982';
    default: return '#CCCCCC';
  }
};

// Mock data structure that matches what we need for node clicks
const mapData = {
  nodes: [
    { id: 'n1', label: 'Personal Security', group: 'Individual' },
    { id: 'n2', label: 'Trauma Recovery', group: 'Individual' },
    { id: 'n3', label: 'Economic Wellbeing', group: 'Individual' },
    
    { id: 'n4', label: 'Community Trust', group: 'Social' },
    { id: 'n5', label: 'Social Cohesion', group: 'Social' },
    { id: 'n6', label: 'Inter-group Dialogue', group: 'Social' },
    
    { id: 'n7', label: 'Violence Recurrence', group: 'Conflict' },
    { id: 'n8', label: 'Group Grievances', group: 'Conflict' },
    
    { id: 'n9', label: 'Reconciliation', group: 'Peace' },
    { id: 'n10', label: 'Peacebuilding Programs', group: 'Peace' },
    
    { id: 'n11', label: 'Inclusive Governance', group: 'Governance' },
    { id: 'n12', label: 'Rule of Law', group: 'Governance' },
    
    { id: 'n13', label: 'Regional Stability', group: 'Geopolitics' },
    { id: 'n14', label: 'External Intervention', group: 'Geopolitics' }
  ],
  // Connection definitions for the flow chart
  edges: [
    { source: 'n1', target: 'n4', polarity: 1, strength: 75 },
    { source: 'n2', target: 'n9', polarity: 1, strength: 80 },
    { source: 'n3', target: 'n7', polarity: -1, strength: 60 },
    { source: 'n4', target: 'n5', polarity: 1, strength: 90 },
    { source: 'n5', target: 'n8', polarity: -1, strength: 70 },
    { source: 'n6', target: 'n9', polarity: 1, strength: 85 },
    { source: 'n7', target: 'n2', polarity: 1, strength: 55 },
    { source: 'n8', target: 'n7', polarity: 1, strength: 75 },
    { source: 'n9', target: 'n5', polarity: 1, strength: 80 },
    { source: 'n10', target: 'n6', polarity: 1, strength: 65 },
    { source: 'n11', target: 'n12', polarity: 1, strength: 90 },
    { source: 'n12', target: 'n7', polarity: -1, strength: 85 },
    { source: 'n13', target: 'n14', polarity: 0, strength: 50 },
    { source: 'n14', target: 'n7', polarity: -1, strength: 65 },
    { source: 'n14', target: 'n10', polarity: 1, strength: 75 },
    { source: 'n11', target: 'n5', polarity: 1, strength: 80 },
    { source: 'n7', target: 'n13', polarity: -1, strength: 70 }
  ]
};

// Generate connections for a node
const getNodeConnections = (nodeId: string) => {
  const outgoing = mapData.edges.filter(edge => edge.source === nodeId);
  const incoming = mapData.edges.filter(edge => edge.target === nodeId);
  
  return {
    outgoing,
    incoming
  };
};

// Helper to get a node's data by id
const getNodeById = (id: string) => {
  return mapData.nodes.find(n => n.id === id);
};

// We'll create a mock cytoscape API for compatibility
const createMockCytoscape = () => {
  return {
    fit: () => {},
    center: () => {},
    zoom: (val?: number) => val || 1,
    layout: () => ({ run: () => {} }),
    getElementById: (id: string) => {
      // Mock methods to get connections when node is clicked
      return {
        outgoers: () => ({
          forEach: (callback: any) => {
            mapData.edges.forEach(edge => {
              if (edge.source === id) {
                const target = mapData.nodes.find(n => n.id === edge.target);
                if (target) {
                  callback({
                    target: () => ({ data: (key: string) => target.label }),
                    data: (key: string) => edge.polarity
                  });
                }
              }
            });
          }
        }),
        incomers: () => ({
          forEach: (callback: any) => {
            mapData.edges.forEach(edge => {
              if (edge.target === id) {
                const source = mapData.nodes.find(n => n.id === edge.source);
                if (source) {
                  callback({
                    source: () => ({ data: (key: string) => source.label }),
                    data: (key: string) => edge.polarity
                  });
                }
              }
            });
          }
        })
      };
    },
    destroy: () => {}
  };
};

export default function SystemsMap({ setCy, onNodeClick }: SystemsMapProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [hoveredNode, setHoveredNode] = useState<string | null>(null);
  
  useEffect(() => {
    // Simulate Cytoscape API for compatibility
    const mockCy = createMockCytoscape();
    setCy(mockCy);
    
    return () => {};
  }, [setCy]);

  const handleNodeClick = (node: NodeData) => {
    onNodeClick(node);
  };

  // Function to show relationship indicators when hovering
  const handleMouseEnter = (nodeId: string) => {
    setHoveredNode(nodeId);
  };

  const handleMouseLeave = () => {
    setHoveredNode(null);
  };

  // Get polarity icon/indicator
  const getPolarityIndicator = (polarity: number) => {
    if (polarity === 1) return <span className="text-green-700 font-bold">+</span>;
    if (polarity === -1) return <span className="text-red-700 font-bold">−</span>;
    return <span className="text-gray-500">○</span>;
  };

  return (
    <div ref={containerRef} className="w-full h-screen overflow-y-auto p-6 bg-gray-50">
      <h2 className="text-2xl font-semibold text-center mb-6 text-gray-800">Peacebuilding Systems Map</h2>
      
      {/* Subsystem Flow Chart */}
      <div className="space-y-6">
        {['Individual', 'Social', 'Peace', 'Conflict', 'Governance', 'Geopolitics'].map(group => {
          const nodes = mapData.nodes.filter(n => n.group === group);
          
          return (
            <div key={group} className="mb-8">
              <h3 
                className="font-semibold text-lg mb-4 text-center px-3 py-2 rounded-md"
                style={{ 
                  backgroundColor: `${getGroupColor(group)}`, 
                  color: '#fff',
                  textShadow: '0 1px 1px rgba(0,0,0,0.2)'
                }}
              >
                {group} Subsystem
              </h3>
              
              <div className="flex flex-wrap gap-4 justify-center">
                {nodes.map(node => {
                  const connections = getNodeConnections(node.id);
                  const isHovered = hoveredNode === node.id;
                  const isConnectedToHovered = hoveredNode && (
                    connections.outgoing.some(e => e.target === hoveredNode) ||
                    connections.incoming.some(e => e.source === hoveredNode)
                  );
                  
                  return (
                    <div key={node.id} className="relative">
                      <div
                        className={`w-64 p-4 rounded-lg shadow transition-all duration-200 cursor-pointer 
                          ${isHovered ? 'scale-105 shadow-md z-10' : ''} 
                          ${isConnectedToHovered ? 'ring-2 ring-offset-2' : ''}
                          ${hoveredNode && !isHovered && !isConnectedToHovered ? 'opacity-60' : ''}`}
                        style={{ 
                          backgroundColor: `${getGroupColor(node.group)}22`,
                          borderLeft: `4px solid ${getGroupColor(node.group)}` 
                        }}
                        onClick={() => handleNodeClick(node)}
                        onMouseEnter={() => handleMouseEnter(node.id)}
                        onMouseLeave={handleMouseLeave}
                      >
                        <h4 className="font-medium text-gray-800">{node.label}</h4>
                        
                        {/* Show connections only when hovering */}
                        {(isHovered || isConnectedToHovered) && (
                          <div className="mt-3 space-y-2 text-sm">
                            {connections.outgoing.length > 0 && (
                              <div>
                                <div className="font-medium text-xs text-gray-600 mb-1">Influences:</div>
                                <ul className="space-y-1 pl-2">
                                  {connections.outgoing.map(edge => {
                                    const targetNode = getNodeById(edge.target);
                                    return targetNode ? (
                                      <li key={edge.target} className="flex items-center space-x-1">
                                        {getPolarityIndicator(edge.polarity)}
                                        <span className="text-xs">{targetNode.label}</span>
                                        <span className="text-xs text-gray-500">({targetNode.group})</span>
                                      </li>
                                    ) : null;
                                  })}
                                </ul>
                              </div>
                            )}
                            
                            {connections.incoming.length > 0 && (
                              <div>
                                <div className="font-medium text-xs text-gray-600 mb-1">Influenced by:</div>
                                <ul className="space-y-1 pl-2">
                                  {connections.incoming.map(edge => {
                                    const sourceNode = getNodeById(edge.source);
                                    return sourceNode ? (
                                      <li key={edge.source} className="flex items-center space-x-1">
                                        {getPolarityIndicator(edge.polarity)}
                                        <span className="text-xs">{sourceNode.label}</span>
                                        <span className="text-xs text-gray-500">({sourceNode.group})</span>
                                      </li>
                                    ) : null;
                                  })}
                                </ul>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                      
                      {/* Connection lines */}
                      {isHovered && connections.outgoing.map(edge => {
                        const targetNode = getNodeById(edge.target);
                        if (!targetNode) return null;
                        
                        // We'll just indicate this visually instead of drawing arrows
                        return null;
                      })}
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
      
      {/* Relationship Key */}
      <div className="mt-8 text-center">
        <div className="inline-flex items-center space-x-6 bg-white px-6 py-3 rounded-lg shadow">
          <div className="flex items-center space-x-2">
            <span className="text-green-700 font-bold text-lg">+</span>
            <span className="text-sm">Strengthens</span>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-red-700 font-bold text-lg">−</span>
            <span className="text-sm">Weakens</span>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-gray-500 text-lg">○</span>
            <span className="text-sm">Stabilizes</span>
          </div>
        </div>
      </div>
    </div>
  );
}
