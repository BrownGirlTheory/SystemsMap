import { Button } from '@/components/ui/button';

interface ToolbarProps {
  onZoomIn: () => void;
  onZoomOut: () => void;
}

export default function Toolbar({ onZoomIn, onZoomOut }: ToolbarProps) {
  return (
    <div className="fixed bottom-4 left-1/2 transform -translate-x-1/2 z-10 bg-white/95 backdrop-blur-sm border border-gray-300 px-4 py-2 rounded-lg shadow-md flex items-center space-x-3">
      <button 
        onClick={onZoomIn}
        className="text-gray-700 hover:bg-green-50 p-2 rounded transition-colors"
        aria-label="Zoom in"
      >
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
          <path fillRule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clipRule="evenodd" />
        </svg>
      </button>
      
      <button 
        onClick={onZoomOut}
        className="text-gray-700 hover:bg-green-50 p-2 rounded transition-colors"
        aria-label="Zoom out"
      >
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
          <path fillRule="evenodd" d="M5 10a1 1 0 011-1h8a1 1 0 110 2H6a1 1 0 01-1-1z" clipRule="evenodd" />
        </svg>
      </button>
    </div>
  );
}
