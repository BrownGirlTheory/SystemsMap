// Types for the systems map data
export interface NodeData {
  id: string;
  label: string;
  group: string;
}

export interface EdgeData {
  source: string;
  target: string;
  polarity: number;
  strength: number;
}

export interface NetworkData {
  nodes: { data: NodeData }[];
  edges: { data: EdgeData }[];
}

export interface NodeConnections {
  strengthens: string[];
  weakens: string[];
  stabilizes: string[];
  strengthenedBy: string[];
  weakenedBy: string[];
  stabilizedBy: string[];
}

export interface ActiveNode {
  id: string;
  label: string;
  group: string;
  connections: NodeConnections;
}

// Example network data for the visualization
export const networkData: NetworkData = {
  nodes: [
    // Individual nodes
    { data: { id: 'n1', label: 'Personal Security', group: 'Individual' } },
    { data: { id: 'n2', label: 'Trauma Recovery', group: 'Individual' } },
    { data: { id: 'n3', label: 'Economic Wellbeing', group: 'Individual' } },
    
    // Social nodes
    { data: { id: 'n4', label: 'Community Trust', group: 'Social' } },
    { data: { id: 'n5', label: 'Social Cohesion', group: 'Social' } },
    { data: { id: 'n6', label: 'Inter-group Dialogue', group: 'Social' } },
    
    // Conflict nodes
    { data: { id: 'n7', label: 'Violence Recurrence', group: 'Conflict' } },
    { data: { id: 'n8', label: 'Group Grievances', group: 'Conflict' } },
    
    // Peace nodes
    { data: { id: 'n9', label: 'Reconciliation', group: 'Peace' } },
    { data: { id: 'n10', label: 'Peacebuilding Programs', group: 'Peace' } },
    
    // Governance nodes
    { data: { id: 'n11', label: 'Inclusive Governance', group: 'Governance' } },
    { data: { id: 'n12', label: 'Rule of Law', group: 'Governance' } },
    
    // Geopolitics nodes
    { data: { id: 'n13', label: 'Regional Stability', group: 'Geopolitics' } },
    { data: { id: 'n14', label: 'External Intervention', group: 'Geopolitics' } }
  ],
  edges: [
    // Sample edges with different polarities (-1: weakens, 0: stabilizes, 1: strengthens)
    { data: { source: 'n1', target: 'n4', polarity: 1, strength: 75 } },
    { data: { source: 'n2', target: 'n9', polarity: 1, strength: 80 } },
    { data: { source: 'n3', target: 'n7', polarity: -1, strength: 60 } },
    { data: { source: 'n4', target: 'n5', polarity: 1, strength: 90 } },
    { data: { source: 'n5', target: 'n8', polarity: -1, strength: 70 } },
    { data: { source: 'n6', target: 'n9', polarity: 1, strength: 85 } },
    { data: { source: 'n7', target: 'n2', polarity: 1, strength: 55 } }, // forms a loop
    { data: { source: 'n8', target: 'n7', polarity: 1, strength: 75 } },
    { data: { source: 'n9', target: 'n5', polarity: 1, strength: 80 } },
    { data: { source: 'n10', target: 'n6', polarity: 1, strength: 65 } },
    { data: { source: 'n11', target: 'n12', polarity: 1, strength: 90 } },
    { data: { source: 'n12', target: 'n7', polarity: -1, strength: 85 } },
    { data: { source: 'n13', target: 'n14', polarity: 0, strength: 50 } },
    { data: { source: 'n14', target: 'n7', polarity: -1, strength: 65 } },
    { data: { source: 'n14', target: 'n10', polarity: 1, strength: 75 } },
    { data: { source: 'n11', target: 'n5', polarity: 1, strength: 80 } },
    { data: { source: 'n7', target: 'n13', polarity: -1, strength: 70 } }
  ]
};
