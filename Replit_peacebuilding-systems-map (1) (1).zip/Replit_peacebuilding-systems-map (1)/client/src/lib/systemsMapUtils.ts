// Find loops in the graph and mark them
export const findLoops = (cy: any) => {
  // Reset existing loop nodes
  cy.nodes().removeClass('loop-node');
  
  // Get all edges
  const edges = cy.edges().map((edge: any) => {
    return {
      source: edge.source().id(),
      target: edge.target().id()
    };
  });
  
  // Use a simple algorithm to find loops
  const visited = new Set<string>();
  
  const findPath = (node: string, target: string, path: string[] = []) => {
    if (visited.has(node)) return false;
    visited.add(node);
    path.push(node);
    
    if (node === target && path.length > 2) {
      // Found a loop
      path.forEach(nodeId => {
        cy.getElementById(nodeId).addClass('loop-node');
      });
      return true;
    }
    
    const neighbors = edges
      .filter(e => e.source === node)
      .map(e => e.target);
      
    for (const neighbor of neighbors) {
      if (findPath(neighbor, target, [...path])) return true;
    }
    
    return false;
  };
  
  // Try to find loops starting from each node
  cy.nodes().forEach((node: any) => {
    visited.clear();
    findPath(node.id(), node.id());
  });
};

// Utility for exporting as SVG
export const saveAs = (blob: Blob, filename: string) => {
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

// Apply filter to nodes by group
export const filterNodesByGroup = (cy: any, group: string, visible: boolean) => {
  cy.nodes().forEach((n: any) => {
    if (n.data('group') === group) {
      n.style('display', visible ? 'element' : 'none');
    }
  });
  cy.fit();
};
