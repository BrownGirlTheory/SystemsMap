import { useEffect, useState } from 'react';
import SystemsMap from '@/components/SystemsMap';
import Legend from '@/components/Legend';
import Toolbar from '@/components/Toolbar';
import NodeDetails from '@/components/NodeDetails';
import { ActiveNode, NodeData } from '@/lib/systemsMapData';

export default function Home() {
  const [cy, setCy] = useState<any>(null);
  const [activeNode, setActiveNode] = useState<ActiveNode | null>(null);
  
  // Functions to be passed to children components
  const zoomIn = () => {
    if (!cy) return;
    const newZoom = cy.zoom() * 1.2;
    cy.zoom(newZoom);
  };

  const zoomOut = () => {
    if (!cy) return;
    const newZoom = cy.zoom() / 1.2;
    cy.zoom(newZoom);
  };

  // When a node is clicked, populate and show the details panel
  const handleNodeClick = (node: NodeData) => {
    if (!node || !cy) return;
    
    // Create active node with connections
    const activeNodeData: ActiveNode = {
      id: node.id,
      label: node.label,
      group: node.group,
      connections: {
        strengthens: [],
        weakens: [],
        stabilizes: [],
        strengthenedBy: [],
        weakenedBy: [],
        stabilizedBy: []
      }
    };

    try {
      // Outgoing edges
      cy.getElementById(node.id).outgoers('edge').forEach((edge: any) => {
        const target = edge.target().data('label');
        const polarity = edge.data('polarity');
        
        if (polarity === 1) activeNodeData.connections.strengthens.push(target);
        else if (polarity === -1) activeNodeData.connections.weakens.push(target);
        else activeNodeData.connections.stabilizes.push(target);
      });
      
      // Incoming edges
      cy.getElementById(node.id).incomers('edge').forEach((edge: any) => {
        const source = edge.source().data('label');
        const polarity = edge.data('polarity');
        
        if (polarity === 1) activeNodeData.connections.strengthenedBy.push(source);
        else if (polarity === -1) activeNodeData.connections.weakenedBy.push(source);
        else activeNodeData.connections.stabilizedBy.push(source);
      });
    } catch (error) {
      console.error("Error processing node connections:", error);
    }
    
    setActiveNode(activeNodeData);
  };

  return (
    <div className="relative h-screen w-full overflow-hidden bg-gray-50">
      <SystemsMap setCy={setCy} onNodeClick={handleNodeClick} />
      <Legend />
      
      <Toolbar 
        onZoomIn={zoomIn} 
        onZoomOut={zoomOut} 
      />
      
      {activeNode && (
        <NodeDetails 
          node={activeNode} 
          onClose={() => setActiveNode(null)} 
        />
      )}
    </div>
  );
}
