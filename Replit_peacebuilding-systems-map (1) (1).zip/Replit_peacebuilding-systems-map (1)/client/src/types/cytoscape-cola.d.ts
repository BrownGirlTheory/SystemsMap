declare module 'cytoscape-cola' {
  import cytoscape from 'cytoscape';
  
  const cola: cytoscape.Ext;
  export default cola;
}