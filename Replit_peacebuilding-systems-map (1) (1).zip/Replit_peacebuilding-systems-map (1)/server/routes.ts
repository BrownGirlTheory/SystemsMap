import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { networkData } from "../client/src/lib/systemsMapData";

export async function registerRoutes(app: Express): Promise<Server> {
  // API endpoints for the systems map
  
  // Get all unique groups from the data
  app.get('/api/groups', (req, res) => {
    const uniqueGroups = Array.from(
      new Set(networkData.nodes.map(n => n.data.group).filter(Boolean))
    ).sort();
    
    res.json(uniqueGroups);
  });
  
  // Get all nodes
  app.get('/api/nodes', (req, res) => {
    res.json(networkData.nodes);
  });
  
  // Get all edges
  app.get('/api/edges', (req, res) => {
    res.json(networkData.edges);
  });
  
  // Get complete network data
  app.get('/api/network', (req, res) => {
    res.json(networkData);
  });

  const httpServer = createServer(app);

  return httpServer;
}
